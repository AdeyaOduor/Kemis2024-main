// import React from 'react'

// function FeatStat() {
//   return (
//     <div class="bg-gray-50 py-24 sm:py-32">
//       <div class="mx-auto max-w-7xl px-6 lg:px-8">
//         <dl class="grid grid-cols-1 gap-x-8 gap-y-16 text-center lg:grid-cols-3">
//           <div class="mx-auto flex max-w-xs flex-col gap-y-4">
//             <dt class="text-base leading-7 text-gray-600">Registered Students</dt>
//             <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl">44 million</dd>
//           </div>
//           <div class="mx-auto flex max-w-xs flex-col gap-y-4">
//             <dt class="text-base leading-7 text-gray-600">Students benefited from EduAfya</dt>
//             <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl">1 Million</dd>
//           </div>
//           <div class="mx-auto flex max-w-xs flex-col gap-y-4">
//             <dt class="text-base leading-7 text-gray-600">Registered Institutions</dt>
//             <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl">86,000</dd>
//           </div>
//         </dl>
//       </div>
//     </div>

//   )
// }

// export default FeatStat

import React from 'react';
// import { AreaChart, Area, PieChart, Pie, Cell, BarChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Label, LineChart } from 'recharts';
import { LineChart, Line, BarChart, AreaChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,Label, Legend, PieChart, Pie, Cell } from 'recharts';

const dataKcpeResults = [
  { year: 2019, boys: 1450, girls: 1470 },
  { year: 2020, boys: 23460, girls: 5480 },
  { year: 2021, boys: 6470, girls: 56490 },
  // Add more data as needed
];

const dataOverallPerformance = [
  { range: '0-100', count: 30 },
  { range: '101-200', count: 50 },
  { range: '201-300', count: 80 },
  { range: '301-400', count: 120 },
  { range: '401-500', count: 90 },
];
const overallkcsePermance = [
  { Grades: 'E', studedents: 1200 },
  { Grades: 'D-', studedents: 1250 },
  { Grades: 'D', studedents: 2400 },
  { Grades: 'D+', studedents: 2300 },
  { Grades: 'C-', studedents: 23799 },
  { Grades: 'C', studedents: 14600 },
  { Grades: 'C+', studedents: 1200 },
  { Grades: 'B-', studedents: 23799 },
  { Grades: 'B', studedents: 14600 },
  { Grades: 'B+', studedents: 1200 },
  { Grades: 'A-', studedents: 23799 },
  { Grades: 'A', studedents: 14600 },
];

// Convert grouped data to an array
//KCSE
const overallKcseGenderPerformance = [
  { Grades: 'E', gender: 'girls', value: 900 },
  { Grades: 'E', gender: 'boys', value: 1200 },
  { Grades: 'D-', gender: 'girls', value: 1250 },
  { Grades: 'D-', gender: 'boys', value: 1270 },
  { Grades: 'D', gender: 'girls', value: 2400 },
  { Grades: 'D', gender: 'boys', value: 2300 },
  { Grades: 'D+', gender: 'girls', value: 21000 },
  { Grades: 'D+', gender: 'boys', value: 19050 },
  { Grades: 'C-', gender: 'girls', value: 23799 },
  { Grades: 'C-', gender: 'boys', value: 14600 },
  { Grades: 'C', gender: 'girls', value: 13000 },
  { Grades: 'C', gender: 'boys', value: 13100 },
  { Grades: 'C+', gender: 'girls', value: 1200 },
  { Grades: 'C+', gender: 'boys', value: 1250 },
  { Grades: 'B-', gender: 'girls', value: 23799 },
  { Grades: 'B-', gender: 'boys', value: 14600 },
  { Grades: 'B', gender: 'girls', value: 13000 },
  { Grades: 'B', gender: 'boys', value: 13100 },
  { Grades: 'B+', gender: 'girls', value: 1200 },
  { Grades: 'B+', gender: 'boys', value: 1250 },
  { Grades: 'A-', gender: 'girls', value: 23799 },
  { Grades: 'A-', gender: 'boys', value: 14600 },
  { Grades: 'A', gender: 'girls', value: 13000 },
  { Grades: 'A', gender: 'boys', value: 13100 },
];
// Group data by gender
const dataKcseByGender = overallKcseGenderPerformance.reduce((acc, entry) => {
  const { Grades, gender, value } = entry;
  if (!acc[Grades]) {
      acc[Grades] = { Grades };
  }
  acc[Grades][gender] = value;
  return acc;
}, {});
// Convert grouped data to an array
const dataKcse = Object.values(dataKcseByGender);

// end of line graph

//start pie chart
const formOneEnrollment = [
  { male: 43000, female: 50459 },
];

const formOneEnrollmentData = [
  { name: 'Male', value: formOneEnrollment[0].male },
  { name: 'Female', value: formOneEnrollment[0].female },
];

const formOneEnrollmentCOLORS = ['#d9289b', '#0b0fb1'];

const formTwoEnrollment = [
  { male: 3000, female: 5459 },
];

const formTwoEnrollmentData = [
  { name: 'Male', value: formOneEnrollment[0].male },
  { name: 'Female', value: formOneEnrollment[0].female },
];

const formTwoEnrollmentCOLORS = ['#681da8', 'green'];
//end pie charts

//area chart

//end area chart


const dataEnrollment = [
  { name: 'Boys', value: 4120 },
  { name: 'Girls', value: 3200 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#D3D3D3'];

const getRandomColor = () => COLORS[Math.floor(Math.random() * COLORS.length)];

function FeatStat() {
  return (
    <div className="bg-gray-50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-x-8 gap-y-16 text-center lg:grid-cols-3">
          <div className="mx-auto flex max-w-xs flex-col gap-y-4">
            {/* Line Chart - KCPE Results Analysis */}
            <h3>KCPE Results Analysis</h3>
            <LineChart width={400} height={200} data={dataKcpeResults}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="year" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="boys" stroke="#8884d8" />
              <Line type="monotone" dataKey="girls" stroke="#82ca9d" />
            </LineChart>
          </div>

          <div className="mx-auto flex max-w-xs flex-col gap-y-4">
            {/* Bar Chart - Overall Performance */}
            <BarChart width={400} height={200} data={dataOverallPerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="range" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#8884d8">
                {dataOverallPerformance.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getRandomColor()} />
                ))}
              </Bar>
            </BarChart>
          </div>

          <div className="mx-auto flex max-w-xs flex-col gap-y-4">
            {/* Doughnut Chart - Total Enrollment */}
            <PieChart width={300} height={200}>
              <Pie dataKey="value" isAnimationActive={false} data={dataEnrollment} cx="50%" cy="50%" outerRadius={80} fill="#8884d8" label>
                {dataEnrollment.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getRandomColor()} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </div>

          {/* <h1 className="text-center" style={{ textDecoration: 'underline' }}>KCSE 2023 Analysis Summary</h1> */}
            <div className="md:flex float-right gap-y-4">
                <div className="md:w-1/2 m-5">

                    <div className="w-full ">

                        <div style={{ width: 'fit-content' }}>
                        <h2>KCSE Performance Report 2022</h2>

                            <BarChart width={400} height={400} data={overallkcsePermance}>
                                <CartesianGrid vertical={true} strokeDasharray="1" />
                                <XAxis dataKey="Grades" label={{ value: 'Grade', position: 'insideBottom', offset: -5 }} style={{ marginBottom: '5px', fill: '#bb5252' }} />
                                <YAxis>
                                    <Label
                                        value="Number of Students"
                                        angle={-90}
                                        position="insideLeft"
                                        offset={5} 
                                        style={{ textAnchor: 'middle', fontSize: '14px' }}
                                        dy={-30} 
                                    />
                                </YAxis>
                                <Tooltip />
                                <Legend />
                                 <Bar dataKey="studedents" fill="#8884d8" name="studedents" />
                                {/* <Bar dataKey="studedents" fill="#82ca9d" name="studedents" /> */}
                                {/* <Bar dataKey="studedents" fill="#0088FE" name="studedents" /> */}
                                {/* <Bar dataKey="studedents" fill="#00C49F" name="studedents" />  */}
                                {/* <Bar dataKey="studedents" fill="#FF8042" name="students" /> */}
                            </BarChart>
                        </div>
                    </div>
                </div>
                <div className="md:w-1/2 m-5">
                    {/* <div className="w-full ">
                        <div style={{ width: 'fit-content' }}>
                            <AreaChart width={400} height={400} data={dataKcse}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="Grades" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey="girls" stroke="#2563eb" name="Girls" />
                                <Line type="monotone" dataKey="boys" stroke="#82ca9d" name="Boys" />
                            </AreaChart>
                        </div>
                    </div> */}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
}

export default FeatStat;
