import React from 'react'

const Login = () => {
    return <div className='dark:text-white'>Login</div>
}

export default Login
