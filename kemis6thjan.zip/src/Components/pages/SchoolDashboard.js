import React from 'react';

const SchoolDashboard = () => {
  return (
    <div>
      <h1>Welcome to Sample Page</h1>
      <p>This is a sample message that demonstrates a React page.</p>
    </div>
  );
};

export default SchoolDashboard;