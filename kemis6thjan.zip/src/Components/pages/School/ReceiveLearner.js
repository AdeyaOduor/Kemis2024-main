import React from 'react'

function ReceiveLearner() {
  return (
    <div>ReceiveLearner</div>
  )
}

export default ReceiveLearner