import React from 'react'

function ReleaseLearner() {
  return (
    <div>ReleaseLearner</div>
  )
}

export default ReleaseLearner