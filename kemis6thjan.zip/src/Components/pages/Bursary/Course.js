import React from "react";

const Course = () => {
    return <div className='dark:text-white'>Course</div>
};

export default Course;
