import React from 'react'

const Home = () => {
    return <div className='dark:text-white'>Home</div>
}

export default Home
