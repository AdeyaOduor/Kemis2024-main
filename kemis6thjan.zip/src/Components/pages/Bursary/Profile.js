import React from 'react'

const Profile = () => {
    return <div className='dark:text-white'>Profile</div>
}

export default Profile
