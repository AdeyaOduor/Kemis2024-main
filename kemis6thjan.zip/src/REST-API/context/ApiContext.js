import React from 'react';

const ApiContext = React.createContext({});

export default ApiContext;